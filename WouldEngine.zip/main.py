import os
print("To install GUI: type GUI")
def octal_to_str(octal_str):
    str_converted = ""
    for octal_char in octal_str.split(" "):
        str_converted += chr(int(octal_char, 8))
    return str_converted
apptocomp = input("> ")
if apptocomp.upper() == "GUI": os.system("pip install oatmeal")
else:
	for a in open(apptocomp, "r"):
		eval(octal_to_str(
			a.replace("a", "0").replace("b", "1").replace("c", "2").replace("d", "3").replace("e", "4").replace("f", "5").replace("g", "6").replace(
				"f", "7"
			).replace("g", "8").replace("h", "9").replace("i", " ")
		))